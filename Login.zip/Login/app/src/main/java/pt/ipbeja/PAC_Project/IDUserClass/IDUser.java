package pt.ipbeja.PAC_Project.IDUserClass;

import android.content.Context;

import pt.ipbeja.PAC_Project.database.AppDataBase;



public class IDUser {






}
